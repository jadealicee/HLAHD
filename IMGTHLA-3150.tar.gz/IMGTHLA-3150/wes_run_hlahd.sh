#!/bin/bash
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12
#SBATCH --mem=64G
#SBATCH --time=24:00:00

# ==============================================================================
# USER ASSIGNMENTS (Update these for each sample or use a wrapper loop)
# ==============================================================================
SAMPLE="SAMPLE_NAME_HERE"
WES_DIR="/nfs/dri/01/WES/WES_archive/WES/WES04_40x/output/WES04_40x_BAMs"
R1="${WES_DIR}/${SAMPLE}_R1.fastq.gz"
R2="${WES_DIR}/${SAMPLE}_R2.fastq.gz"

# ==============================================================================
# 1. Environment Set Up
# ==============================================================================
# Clear pre-existing environment library paths to avoid compilation clashes
unset LD_PRELOAD

# Initialize Conda for your user and activate the exact hlahd environment
source ~/anaconda3/etc/profile.d/conda.sh || source /shared/home1/c.c25077499/.bashrc
conda activate hlahd

# Dynamic paths to current working software folder
HLAHD_DIR="/scratch/SCWF00010/legacydata/c.c25077499_20260130-112657/hlahd.1.7.1"
export PATH="${HLAHD_DIR}/bin:${HLAHD_DIR}:${PATH}"
export LD_LIBRARY_PATH=$CONDA_PREFIX/lib:$LD_LIBRARY_PATH

# Memory adjustments for large-scale FASTQ mapping stability
ulimit -s unlimited
ulimit -n 2048

cd ${HLAHD_DIR}

# Ensure output destination exists
mkdir -p ./output

# ==============================================================================
# 2. Run HLA-HD
# ==============================================================================
bash ./hlahd.sh \
    -t 12 \
    -m 150 \
    -f ./freq_data \
    "$R1" \
    "$R2" \
    ./HLA_gene.split.txt \
    ./dictionary315 \
    "${SAMPLE}_Result" \
    ./output
